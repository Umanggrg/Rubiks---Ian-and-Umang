package ShortestPath;
import rubikcube.RubikCube;
import rubikcube.RubikCube.FACE;
import rubikcube.RubikSide;
import solutioning.strategy.Action;

import org.jgrapht.Graph;
import org.jgrapht.alg.shortestpath.BFSShortestPath;
import org.jgrapht.graph.DefaultDirectedGraph;
import org.jgrapht.graph.DefaultEdge;

import java.util.ArrayList;
import java.util.List;

public class RubiksSolve {
    public static void main(String[] args) {
        // Initialize a Rubik's Cube with a specified size
        int cubeSize = 3;
        RubikCube startCube = new RubikCube(cubeSize);

        // Measure the time taken to solve the cube
        long startTime = System.currentTimeMillis() / 1000;

        // Generate a graph representing all possible moves from the start state
        Graph<RubikCube, DefaultEdge> rubiksGraph = createRubiksGraph(startCube, 5);

        // Define the goal state of the Rubik's Cube (solved state)
        RubikCube goalCube = new RubikCube(cubeSize);

        // Find the shortest path from the start state to the goal state
        List<DefaultEdge> shortestPath = findShortestPath(rubiksGraph, startCube, goalCube);
        System.out.println("Shortest path to solve the cube: " + shortestPath);

        // Calculate and display the time taken for solving the cube
        long endTime = System.currentTimeMillis() / 1000;
        long duration = endTime - startTime;
        System.out.println("Time taken to solve (seconds): " + duration);
    }

    // Creates a graph of Rubik's Cube states and transitions
    public static Graph<RubikCube, DefaultEdge> createRubiksGraph(RubikCube initialCube, int depthLimit) {
        Graph<RubikCube, DefaultEdge> rubiksGraph = new DefaultDirectedGraph<>(DefaultEdge.class);
        rubiksGraph.addVertex(initialCube);
        generateGraph(initialCube, rubiksGraph, depthLimit);
        return rubiksGraph;
    }

    // Recursively generates the graph of possible moves up to a certain depth
    private static void generateGraph(RubikCube cube, Graph<RubikCube, DefaultEdge> graph, int depth) {
        if (depth == 0) return;

        for (Action<RubikCube> action : cube.getAllActions()) {
            try {
                RubikCube newState = cube.clone();
                action.performAction(newState);
                if (!graph.containsVertex(newState)) {
                    graph.addVertex(newState);
                    graph.addEdge(cube, newState);
                    generateGraph(newState, graph, depth - 1);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // Finds the shortest path in the graph from the source to the target
    public static List<DefaultEdge> findShortestPath(Graph<RubikCube, DefaultEdge> graph, RubikCube source, RubikCube target) {
        BFSShortestPath<RubikCube, DefaultEdge> bfs = new BFSShortestPath<>(graph);

        // Attempt to find a path to a solved cube state
        RubikCube solvedCube = graph.vertexSet().stream()
                .filter(RubikCube::isComplete)
                .findFirst()
                .orElse(null);

        if (solvedCube != null) {
            System.out.println("Solution found");
            return bfs.getPath(source, solvedCube).getEdgeList();
        } else {
            System.out.println("Solved state not found in the graph.");
            return new ArrayList<>();
        }
    }
}
