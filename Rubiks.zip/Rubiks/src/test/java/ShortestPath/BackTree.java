package ShortestPath;
import org.jgrapht.graph.DefaultEdge;
import solutioning.strategy.Action;
import rubikcube.RubikCube;
import rubikcube.RubikSide;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class BackTree {
    // Stores the states of the Rubik's Cube and their respective levels in the search
    public Map<RubikCube, Integer> reverseSearchMap;
    // Reference to the corresponding front tree in the bi-directional search
    public FrontTree correspondingFrontTree;
    // Counter for the total number of nodes in the tree
    public int num_of_nodes;
    // A map to hold Rubik's Cube states and their corresponding depth in the search tree
    public Map<RubiksCubeState, Integer> depthMap;

    // Constructor initializing the reverse search tree
    public BackTree() {
        depthMap = new HashMap<>();
        reverseSearchMap = new HashMap<>();
        num_of_nodes = 0;
        correspondingFrontTree = new FrontTree(this);
        initializeStartingStates();
    }

    // Initializes the search tree with the first layer of combinations
    private void initializeStartingStates() {
        System.out.println("Starting Reverse Expansion");
        RubiksCubeState initialState = new RubiksCubeState(new RubikCube(3), 0, null);
        depthMap.put(initialState, 0);

        // Iterate through all possible actions from the initial state
        for (Action<RubikCube> action : initialState.getRubiksCube().getAllActions()) {
            try {
                RubikCube newState = initialState.getRubiksCube().clone();
                newState.performAction(action);
                RubiksCubeState newStateNode = new RubiksCubeState(newState, initialState.getLevel(), initialState);
                depthMap.put(newStateNode, 1);
                num_of_nodes++;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Check for a solution or expand the front tree if necessary
        if (correspondingFrontTree.checkSolution(depthMap)) {
            System.out.println("Solution Found");
        } else {
            System.out.println("Expanding Front Tree");
            correspondingFrontTree.generateMoreFrontStates();
        }
    }

    // Generates additional states for the reverse search tree
    public void expandMoreStates() {
        // Temporary map to hold the current level nodes
        Map<RubiksCubeState, Integer> currentLevelNodes = new HashMap<>(depthMap);

        // Iterate over each node in the current level to generate the next level
        for (Map.Entry<RubiksCubeState, Integer> entry : currentLevelNodes.entrySet()) {
            RubiksCubeState currentNode = entry.getKey();
            Integer currentDepth = entry.getValue();

            // Apply all possible actions to the current node
            for (Action<RubikCube> action : currentNode.getRubiksCube().getAllActions()) {
                try {
                    RubikCube modifiedState = currentNode.getRubiksCube().clone();
                    modifiedState.performAction(action);
                    RubiksCubeState newTreeNode = new RubiksCubeState(modifiedState, currentNode.getLevel() + 1, currentNode);

                    // Add the new state if it's not already in the tree
                    if (!depthMap.containsKey(newTreeNode)) {
                        depthMap.put(newTreeNode, newTreeNode.calculateMisplacedFacelets());
                        num_of_nodes++;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        // Check for solution or expand the front tree
        if (correspondingFrontTree.checkSolution(depthMap)){
            System.out.println("Solution Found");
        } else {
            System.out.println("Expanding Front Tree");
            correspondingFrontTree.generateMoreFrontStates();
        }
    }

    // Returns a list of all nodes in the reverse search tree
    public List<RubikCube> getAllReverseTreeNodes() {
        return new ArrayList<>(reverseSearchMap.keySet());
    }

    // Accessor method for the reverse search tree
    public Map<RubiksCubeState, Integer> getReverseSearchTree() {
        return depthMap;
    }

    // Accessor method for the total number of nodes
    public int getTotalNodeCount() {
        return num_of_nodes;
    }

    // Other methods related to managing the reverse search tree nodes
    // ...
}













